import {expect, test, type Page} from '@playwright/test';
import {writeFile} from 'node:fs/promises';
import path from 'node:path';
import {registerSyntheticUser, syntheticUser} from './support/synthetic-auth';
import {settleVisual} from './support/rf15-visual';

const dir = process.env.CF_REVIEW_EVIDENCE!;
async function start(page: Page, key: string) {
  await page.clock.setFixedTime(new Date('2027-01-15T12:00:00Z'));
  await registerSyntheticUser(page, syntheticUser('A', process.env.CF_E2E_NAMESPACE + key));
  await page.setViewportSize({width: 360, height: 800});
}
async function post(page: Page, url: string, data: unknown) {
  const response = await page.request.post('/api' + url, {data});
  expect(response.ok(), await response.text()).toBe(true);
  return response.json();
}
async function evidence(page: Page, name: string) {
  await settleVisual(page);
  await page.screenshot({path: path.join(dir, name + '.png')});
  await writeFile(path.join(dir, name + '.json'), JSON.stringify({
    snapshot: await page.locator('body').ariaSnapshot(),
    focus: await page.evaluate(() => ({tag: document.activeElement?.tagName, label: document.activeElement?.getAttribute('aria-label')})),
  }, null, 2));
}

test('Residual CF014: Escape no detalhe longo da meta', async ({page}) => {
  await start(page, '-goal');
  const goal = await post(page, '/goals', {title:'Meta residual longa', type:'MONETARY', targetValue:1000, deadline:'2027-12-31', color:'BLUE', useChecklist:true});
  for (let i = 0; i < 10; i++) await post(page, `/goals/${goal.id}/items`, {name:`Item ${i} longo para rolagem da meta`, estimatedPrice:100});
  await page.goto('/metas');
  await page.getByText(goal.title, {exact:true}).click();
  await page.getByText('Item 9 longo para rolagem da meta', {exact:true}).scrollIntoViewIfNeeded();
  await evidence(page, 'goal-before-escape');
  await page.keyboard.press('Escape');
  await evidence(page, 'goal-after-escape');
  await expect(page.getByRole('heading', {name:goal.title, exact:true})).toHaveCount(1);
  await expect(page.getByRole('button', {name:`Ver detalhes da meta ${goal.title}`})).toBeFocused();
});

test('Residual CF014: Escape no detalhe diário do hábito', async ({page}) => {
  await start(page, '-habit');
  const habit = await post(page, '/habits', {name:'Hábito residual diário', description:'Descrição sintética extensa para verificar as ações e o calendário. '.repeat(3), frequency:'DAILY', icon:'Flame', color:'BLUE'});
  await page.goto('/habitos');
  const opener = page.getByRole('button', {name:`Ver detalhes do hábito ${habit.name}`});
  await opener.focus(); await page.keyboard.press('Enter');
  const detail = page.locator('form').filter({hasText:habit.description});
  await expect(detail).toBeVisible();
  await evidence(page, 'habit-before-escape');
  await page.keyboard.press('Escape');
  await evidence(page, 'habit-after-escape');
  await expect(detail).toHaveCount(0);
  await expect(opener).toBeFocused();
});
