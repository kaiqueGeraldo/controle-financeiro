import {expect, test, type Page} from '@playwright/test';
import {writeFile} from 'node:fs/promises';
import path from 'node:path';
import {registerSyntheticUser, syntheticUser} from './support/synthetic-auth';
import {settleVisual} from './support/rf15-visual';

const dir = process.env.CF_REVIEW_EVIDENCE!;
async function start(page: Page, key: string) {
  await page.clock.setFixedTime(new Date('2027-01-15T12:00:00Z'));
  await registerSyntheticUser(page, syntheticUser('A', process.env.CF_E2E_NAMESPACE + key));
  await page.setViewportSize({width: 360, height: 800});
}
async function post(page: Page, url: string, data: unknown) {
  const response = await page.request.post('/api' + url, {data});
  expect(response.ok(), await response.text()).toBe(true);
  return (await response.text()) ? response.json() : null;
}
async function evidence(page: Page, name: string) {
  await settleVisual(page);
  await page.screenshot({path: path.join(dir, name + '.png')});
  await writeFile(path.join(dir, name + '.json'), JSON.stringify({
    snapshot: await page.locator('body').ariaSnapshot(),
    focus: await page.evaluate(() => ({tag: document.activeElement?.tagName, label: document.activeElement?.getAttribute('aria-label')})),
  }, null, 2));
}

test('Residual CF014: Escape no detalhe longo da meta', async ({page}) => {
  await start(page, '-goal');
  const goal = await post(page, '/goals', {title:'Meta residual longa', type:'MONETARY', targetValue:1000, deadline:'2027-12-31', color:'BLUE', useChecklist:true});
  for (let i = 0; i < 10; i++) await post(page, `/goals/${goal.id}/items`, {name:`Item ${i} longo para rolagem da meta`, estimatedPrice:100});
  await page.goto('/metas');
  await page.getByText(goal.title, {exact:true}).click();
  await page.getByText('Item 9 longo para rolagem da meta', {exact:true}).scrollIntoViewIfNeeded();
  await evidence(page, 'goal-before-escape');
  await page.keyboard.press('Escape');
  await evidence(page, 'goal-after-escape');
  await expect(page.getByRole('heading', {name:goal.title, exact:true})).toHaveCount(1);
  await expect(page.getByRole('button', {name:`Ver detalhes da meta ${goal.title}`})).toBeFocused();
});

test('Residual CF014: Escape no detalhe diário do hábito', async ({page}) => {
  await start(page, '-habit');
  const habit = await post(page, '/habits', {name:'Hábito residual diário', description:'Descrição sintética extensa para verificar as ações e o calendário. '.repeat(3), frequency:'DAILY', icon:'Flame', color:'BLUE'});
  await page.goto('/habitos');
  const opener = page.getByRole('button', {name:`Ver detalhes do hábito ${habit.name}`});
  await opener.focus(); await page.keyboard.press('Enter');
  const detail = page.locator('form').filter({hasText:habit.description});
  await expect(detail).toBeVisible();
  await evidence(page, 'habit-before-escape');
  await page.keyboard.press('Escape');
  await evidence(page, 'habit-after-escape');
  await expect(detail).toHaveCount(0);
  await expect(opener).toBeFocused();
});

for (const [zone, before, after] of [
  ['America/Sao_Paulo','2027-02-06T02:59:59Z','2027-02-06T03:00:00Z'],
  ['UTC','2027-02-05T23:59:59Z','2027-02-06T00:00:00Z'],
  ['Pacific/Kiritimati','2027-02-05T09:59:59Z','2027-02-05T10:00:00Z'],
]) for (const event of ['focus','visibilitychange']) {
  test(`Residual RF15-04: ${zone} ${event} isolado mantém competência e não relê saldo`, async ({browser}) => {
    const context = await browser.newContext({baseURL:process.env.CF_TEST_BASE_URL, timezoneId:zone, locale:'pt-BR'});
    const page = await context.newPage();
    try {
      await start(page, '-'+zone.replaceAll('/','-')+'-'+event);
      await page.clock.setFixedTime(new Date(before));
      const card = await post(page,'/cards',{name:'Fatura residual', last4Digits:'4242',limit:1000,closingDay:31,dueDay:5,brand:'VISA',color:'#7c3aed'});
      const cats = await (await page.request.get('/api/categories?type=EXPENSE')).json();
      await post(page,'/cards/transaction',{cardId:card.id,categoryId:cats[0].id,description:'Compra residual',amount:120,date:'2027-01-15',time:null,totalInstallments:1});
      await page.goto('/cartoes');
      await page.getByRole('button',{name:'Ver fatura de Fatura residual, final 4242'}).click();
      const d = page.getByRole('dialog',{name:'Fatura residual •••• 4242',exact:true});
      await d.getByRole('button',{name:'Mês anterior da fatura'}).click();
      await expect(d.getByText('Compra residual',{exact:true})).toBeVisible();
      await expect(d.getByRole('button',{name:'Adiantar Fatura'})).toBeVisible();
      const requests: string[] = [];
      page.on('request', r => {if(r.url().includes('/api/cards')) requests.push(r.url());});
      await page.clock.setFixedTime(new Date(after));
      // FixedTime changes Date only: no timer, other event, navigation or data refresh.
      await page.evaluate(event => {
        if(event === 'focus') window.dispatchEvent(new Event('focus'));
        else {if(document.visibilityState !== 'visible') throw new Error('Page must be visible'); document.dispatchEvent(new Event('visibilitychange'));}
      },event);
      await expect(d.getByRole('button',{name:'Pagar Atrasada'})).toBeVisible();
      await expect(d.getByText('Janeiro de 2027',{exact:true})).toBeVisible();
      await expect(d.getByText('Fecha: 31 de jan')).toBeVisible();
      await expect(d.getByText('Vence: 05 de fev')).toBeVisible();
      expect(requests).toEqual([]);
      await evidence(page, 'calendar-'+zone.replaceAll('/','-')+'-'+event);
    } finally {await context.close();}
  });
}

test('Residual CF014: rascunhos, camadas e retorno dos detalhes', async ({page}) => {
  await start(page,'-layers');
  const goal = await post(page,'/goals',{title:'Meta camadas',type:'MONETARY',targetValue:1000,deadline:'2027-12-31',color:'BLUE',useChecklist:true});
  await post(page,`/goals/${goal.id}/items`,{name:'Item preservado',estimatedPrice:100});
  await page.goto('/metas');
  const opener = page.getByRole('button',{name:'Ver detalhes da meta Meta camadas'});
  await opener.focus(); await page.keyboard.press('Enter');
  const detail = page.getByRole('dialog',{name:'Detalhes da meta Meta camadas'});
  await expect(detail.getByRole('button',{name:'Fechar detalhe da meta'})).toBeFocused();
  await page.keyboard.press('Shift+Tab'); expect(await detail.evaluate(d=>d.contains(document.activeElement))).toBe(true);
  await detail.getByRole('button',{name:'Editar meta'}).click();
  await detail.locator('input').first().fill('Rascunho meta');
  await page.keyboard.press('Escape'); await expect(detail).toBeVisible();
  await detail.getByRole('button',{name:'Editar meta'}).click();
  await expect(detail.locator('input').first()).toHaveValue('Meta camadas');
  await page.keyboard.press('Escape');
  const remove = detail.getByRole('button',{name:'Remover item'});
  await remove.click();
  const child = page.getByRole('dialog',{name:'Excluir Sub-item'});
  await expect(child).toBeVisible(); await page.keyboard.press('Escape');
  await expect(child).toHaveCount(0); await expect(detail).toBeVisible(); await expect(remove).toBeFocused();
  await evidence(page,'goal-nested-return');
  await page.keyboard.press('Escape'); await expect(opener).toBeFocused();
  expect(await page.evaluate(()=>document.body.style.overflow)).not.toBe('hidden');

  const habit = await post(page,'/habits',{name:'Hábito rascunho',description:'Original preservado',frequency:'DAILY',icon:'Flame',color:'BLUE'});
  await page.goto('/habitos');
  const habitOpener = page.getByRole('button',{name:`Ver detalhes do hábito ${habit.name}`});
  await habitOpener.click();
  const h = page.getByRole('dialog',{name:`Detalhes do hábito ${habit.name}`});
  await expect(h.getByRole('button',{name:'Fechar detalhe do hábito'})).toBeFocused();
  await h.getByRole('button',{name:'Editar Hábito'}).click(); await h.locator('input').first().fill('Rascunho hábito');
  await page.keyboard.press('Escape'); await expect(h).toBeVisible();
  await h.getByRole('button',{name:'Editar Hábito'}).click(); await expect(h.locator('input').first()).toHaveValue(habit.name);
  await page.keyboard.press('Escape'); await page.keyboard.press('Escape'); await expect(habitOpener).toBeFocused();
  await page.reload(); await expect(habitOpener).toBeVisible(); await expect(page.getByText('Rascunho hábito')).toHaveCount(0);
});
